import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  subValue?: string;
  trend?: "up" | "down" | "neutral";
  icon: LucideIcon;
  color?: "primary" | "secondary" | "accent" | "default";
}

export function StatsCard({ title, value, subValue, trend, icon: Icon, color = "default" }: StatsCardProps) {
  const colorStyles = {
    primary: "bg-primary text-primary-foreground",
    secondary: "bg-secondary text-secondary-foreground",
    accent: "bg-accent text-accent-foreground",
    default: "bg-card text-card-foreground border border-border/50",
  };
  
  const iconStyles = {
    primary: "bg-white/20 text-white",
    secondary: "bg-white/20 text-white",
    accent: "bg-white/20 text-white",
    default: "bg-primary/10 text-primary",
  };

  return (
    <div className={cn(
      "rounded-2xl p-6 shadow-lg shadow-black/5 hover:shadow-xl hover:-translate-y-1 transition-all duration-300",
      colorStyles[color]
    )}>
      <div className="flex items-start justify-between">
        <div>
          <p className={cn("text-sm font-medium mb-1", color !== 'default' ? "text-white/80" : "text-muted-foreground")}>
            {title}
          </p>
          <h3 className="text-3xl font-bold font-display tracking-tight">{value}</h3>
          {subValue && (
            <p className={cn("text-xs mt-2 font-medium", color !== 'default' ? "text-white/60" : "text-muted-foreground")}>
              {subValue}
            </p>
          )}
        </div>
        <div className={cn("p-3 rounded-xl", iconStyles[color])}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
