import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Trophy, 
  Table, 
  Upload, 
  Settings as SettingsIcon,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigation = [
    { name: 'Dashboard', href: '/', icon: LayoutDashboard },
    { name: 'Bracket', href: '/bracket', icon: Trophy },
    { name: 'Leaderboard', href: '/leaderboard', icon: Table },
    { name: 'Data Entry', href: '/import', icon: Upload },
    { name: 'Settings', href: '/settings', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col md:flex-row">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 bg-primary text-primary-foreground border-r border-primary/20 shadow-xl z-50">
        <div className="p-6 border-b border-primary-foreground/10">
          <div className="flex items-center gap-3">
             <div className="h-10 w-10 bg-accent rounded-lg flex items-center justify-center text-accent-foreground font-bold text-xl shadow-lg shadow-black/20">
               LT
             </div>
             <div>
               <h1 className="text-lg font-bold font-display leading-tight">March Madness</h1>
               <p className="text-xs text-primary-foreground/60 font-medium">Lending Tournament</p>
             </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 mt-4">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.name} href={item.href}>
                <div 
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group cursor-pointer",
                    isActive 
                      ? "bg-white/10 text-white shadow-sm border border-white/10" 
                      : "text-primary-foreground/70 hover:text-white hover:bg-white/5"
                  )}
                >
                  <item.icon className={cn("h-5 w-5", isActive ? "text-accent" : "text-current")} />
                  <span className="font-medium">{item.name}</span>
                  {isActive && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_8px_rgba(255,158,27,0.8)]" />
                  )}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 mt-auto">
          <div className="bg-gradient-to-br from-secondary to-primary p-4 rounded-xl border border-white/10 text-center">
            <p className="text-xs font-semibold text-white/90">Lending Tournament</p>
            <p className="text-[10px] text-white/60 mt-1">March Madness Edition</p>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden bg-primary p-4 text-white flex justify-between items-center sticky top-0 z-50 shadow-md">
         <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-accent rounded flex items-center justify-center text-primary font-bold">LT</div>
            <span className="font-display font-bold">Lending Tournament</span>
         </div>
         <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
           {isMobileMenuOpen ? <X /> : <Menu />}
         </Button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-primary z-40 pt-20 px-4 animate-in fade-in slide-in-from-top-10">
          <nav className="space-y-2">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <div 
                  className={cn(
                    "flex items-center gap-3 px-4 py-4 rounded-xl mb-2",
                    location === item.href ? "bg-white/10 text-white" : "text-white/70"
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <item.icon className="h-6 w-6" />
                  <span className="text-lg font-medium">{item.name}</span>
                </div>
              </Link>
            ))}
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 lg:p-10 max-w-full overflow-x-hidden">
        <div className="max-w-7xl mx-auto space-y-8 animate-in">
          {children}
        </div>
      </main>
    </div>
  );
}
