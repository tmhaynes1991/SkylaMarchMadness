import { useParticipants, useStats, useTournamentState } from "@/hooks/use-tournament";
import { Layout } from "@/components/Layout";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Search, Trophy, Medal } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Leaderboard() {
  const { data: participants, isLoading: pLoading } = useParticipants();
  const { data: stats, isLoading: sLoading } = useStats();
  const { data: state, isLoading: stLoading } = useTournamentState();
  const [search, setSearch] = useState("");

  const isLoading = pLoading || sLoading || stLoading;

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </Layout>
    );
  }

  // Combine data
  const currentRound = state?.currentRound || 1;
  
  const leaderboardData = participants?.map(p => {
    const pStats = stats?.filter(s => s.participantId === p.id && s.roundNumber === currentRound) || [];
    // If multiple stats entries for same round (shouldn't happen, but safe logic), sum them or take latest
    const currentStats = pStats[0];

    return {
      ...p,
      weeklyLoans: currentStats?.weeklyLoans || 0,
      gapPct: currentStats?.gapPct || 0,
      mbpPct: currentStats?.mbpPct || 0,
      dpPct: currentStats?.dpPct || 0,
      score: currentStats?.totalScore || 0,
    };
  }).filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.score - a.score);

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display text-primary">Leaderboard</h1>
          <p className="text-muted-foreground">Round {currentRound} Standings</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search participant..." 
            className="pl-9 bg-white"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/30">
            <TableRow>
              <TableHead className="w-[80px]">Rank</TableHead>
              <TableHead>Participant</TableHead>
              <TableHead className="text-right">Weekly Loans</TableHead>
              <TableHead className="text-right">GAP %</TableHead>
              <TableHead className="text-right">MBP %</TableHead>
              <TableHead className="text-right">DP %</TableHead>
              <TableHead className="text-right font-bold text-primary">Total Score</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {leaderboardData?.length === 0 ? (
               <TableRow>
                 <TableCell colSpan={7} className="h-24 text-center">No participants found.</TableCell>
               </TableRow>
            ) : (
              leaderboardData?.map((row, index) => (
                <TableRow key={row.id} className="group hover:bg-muted/20 transition-colors">
                  <TableCell className="font-medium">
                    {index === 0 && <Trophy className="h-5 w-5 text-yellow-500 inline mr-1" />}
                    {index === 1 && <Medal className="h-5 w-5 text-gray-400 inline mr-1" />}
                    {index === 2 && <Medal className="h-5 w-5 text-amber-600 inline mr-1" />}
                    <span className={cn(index < 3 ? "font-bold" : "text-muted-foreground")}>#{index + 1}</span>
                  </TableCell>
                  <TableCell className="font-medium text-foreground">{row.name}</TableCell>
                  <TableCell className="text-right">{row.weeklyLoans}</TableCell>
                  <TableCell className="text-right">{Number(row.gapPct).toFixed(1)}%</TableCell>
                  <TableCell className="text-right">{Number(row.mbpPct).toFixed(1)}%</TableCell>
                  <TableCell className="text-right">{Number(row.dpPct).toFixed(1)}%</TableCell>
                  <TableCell className="text-right">
                    <span className="inline-block px-2 py-1 bg-primary/10 text-primary rounded-lg font-bold">
                      {row.score}
                    </span>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </Layout>
  );
}
