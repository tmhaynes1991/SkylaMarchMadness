import { useState, useRef } from "react";
import { Layout } from "@/components/Layout";
import { useBulkUpdateStats, useParticipants, useTournamentState } from "@/hooks/use-tournament";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Upload, FileUp, CheckCircle2, AlertCircle } from "lucide-react";
import Papa from "papaparse";
import { useToast } from "@/hooks/use-toast";

export default function DataEntry() {
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const { data: participants } = useParticipants();
  const { data: state } = useTournamentState();
  const updateStats = useBulkUpdateStats();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      parseCSV(e.target.files[0]);
    }
  };

  const parseCSV = (file: File) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        console.log("Parsed:", results.data);
        setParsedData(results.data);
      },
      error: (error) => {
        toast({
          title: "Error parsing CSV",
          description: error.message,
          variant: "destructive"
        });
      }
    });
  };

  const handleSubmit = () => {
    if (!parsedData.length || !participants || !state) return;

    // Map CSV data to stats objects
    // Expected CSV columns: LenderID, Loans, GAP, MBP, DP, Auto, HELOC
    const statsToUpdate = parsedData.map((row: any) => {
      const participant = participants.find(p => p.lenderId === row['LenderID'] || p.name === row['Name']);
      
      if (!participant) return null;

      return {
        participantId: participant.id,
        roundNumber: state.currentRound,
        weeklyLoans: Number(row['Loans'] || 0),
        gapPct: row['GAP'] ? String(row['GAP']).replace('%', '') : "0",
        mbpPct: row['MBP'] ? String(row['MBP']).replace('%', '') : "0",
        dpPct: row['DP'] ? String(row['DP']).replace('%', '') : "0",
        autoLoansCount: Number(row['Auto'] || 0),
        helocCount: Number(row['HELOC'] || 0),
      };
    }).filter(Boolean); // Remove nulls (unmatched participants)

    if (statsToUpdate.length === 0) {
      toast({
        title: "No matching participants",
        description: "Could not match any rows to existing participants. Check LenderID column.",
        variant: "destructive"
      });
      return;
    }

    updateStats.mutate(statsToUpdate as any, {
      onSuccess: () => {
        toast({
          title: "Success",
          description: `Updated stats for ${statsToUpdate.length} participants.`,
        });
        setFile(null);
        setParsedData([]);
        if (fileInputRef.current) fileInputRef.current.value = "";
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to update stats.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <Layout>
       <div className="mb-8">
        <h1 className="text-3xl font-bold font-display text-primary">Data Entry</h1>
        <p className="text-muted-foreground">Import weekly performance stats</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* CSV Import */}
        <Card className="border-border/50 shadow-lg shadow-black/5">
          <CardHeader>
            <div className="h-10 w-10 bg-primary/10 text-primary rounded-lg flex items-center justify-center mb-2">
              <FileUp className="h-6 w-6" />
            </div>
            <CardTitle>Import CSV</CardTitle>
            <CardDescription>
              Upload a CSV file with columns: LenderID, Loans, GAP, MBP, DP, Auto, HELOC
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div 
              className="border-2 border-dashed border-border hover:border-primary/50 transition-colors rounded-xl p-8 text-center cursor-pointer bg-muted/20"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-sm font-medium text-foreground">
                {file ? file.name : "Click to upload or drag and drop"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">CSV files only</p>
              <input 
                type="file" 
                accept=".csv" 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleFileChange}
              />
            </div>

            {parsedData.length > 0 && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Ready to import</AlertTitle>
                <AlertDescription className="text-green-700">
                  {parsedData.length} rows parsed successfully.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col gap-2">
              <Button 
                className="w-full bg-primary hover:bg-primary/90" 
                disabled={!parsedData.length || updateStats.isPending}
                onClick={handleSubmit}
              >
                {updateStats.isPending ? "Importing..." : "Process Import"}
              </Button>
              <Button
                className="w-full"
                variant="outline"
                onClick={() => {
                  const csvContent = "data:text/csv;charset=utf-8,LenderID,Loans,GAP,MBP,DP,Auto,HELOC\n1234,5,45%,18%,35%,1,0";
                  const encodedUri = encodeURI(csvContent);
                  const link = document.createElement("a");
                  link.setAttribute("href", encodedUri);
                  link.setAttribute("download", "stats_template.csv");
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                }}
              >
                Download Template
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Instructions / Template */}
        <Card className="border-border/50 shadow-lg shadow-black/5">
           <CardHeader>
             <CardTitle>Data Format Guide</CardTitle>
           </CardHeader>
           <CardContent className="prose prose-sm text-muted-foreground">
             <p>Ensure your CSV file strictly follows this header format:</p>
             <div className="bg-muted p-3 rounded-md font-mono text-xs overflow-x-auto">
               LenderID,Loans,GAP,MBP,DP,Auto,HELOC
             </div>
             <ul className="mt-4 space-y-2">
               <li><strong>LenderID</strong>: Must match the Lender ID in the system.</li>
               <li><strong>Loans</strong>: Number of loans closed this week.</li>
               <li><strong>GAP/MBP/DP</strong>: Percentage values (e.g., 50 or 50%).</li>
               <li><strong>Auto/HELOC</strong>: Count of additional product sales.</li>
             </ul>
             
             <Alert className="mt-6">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Warning</AlertTitle>
                <AlertDescription>
                  Re-uploading for the same round will overwrite existing stats for those participants.
                </AlertDescription>
              </Alert>
           </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
