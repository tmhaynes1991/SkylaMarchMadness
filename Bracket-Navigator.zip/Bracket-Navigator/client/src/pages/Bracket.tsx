import { useMatchups, useTournamentState, useAdvanceRound, useGenerateMatchups } from "@/hooks/use-tournament";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, ChevronRight, Wand2, RefreshCw, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { toPng } from 'html-to-image';
import { useRef } from "react";

export default function Bracket() {
  const { data: matchups, isLoading: matchupsLoading } = useMatchups();
  const { data: state, isLoading: stateLoading } = useTournamentState();
  const generate = useGenerateMatchups();
  const advance = useAdvanceRound();
  const bracketRef = useRef<HTMLDivElement>(null);

  const isLoading = matchupsLoading || stateLoading;

  if (isLoading) return (
    <Layout>
       <div className="space-y-4">
         <Skeleton className="h-12 w-48" />
         <div className="grid grid-cols-4 gap-8 h-[600px]">
           <Skeleton className="h-full w-full rounded-xl" />
           <Skeleton className="h-full w-full rounded-xl" />
           <Skeleton className="h-full w-full rounded-xl" />
           <Skeleton className="h-full w-full rounded-xl" />
         </div>
       </div>
    </Layout>
  );

  const currentRound = state?.currentRound || 1;
  const hasMatchups = matchups && matchups.length > 0;

  // Group matchups by round
  const rounds = [1, 2, 3, 4];
  const matchupsByRound = rounds.map(r => 
    matchups?.filter(m => m.roundNumber === r).sort((a, b) => a.matchId - b.matchId) || []
  );

  const handleGenerate = () => {
    if (confirm("This will regenerate the bracket based on seeds. Existing manual overrides may be lost. Continue?")) {
      generate.mutate();
    }
  };

  const handleAdvance = () => {
    if (confirm(`Advance winners from Round ${currentRound} to Round ${currentRound + 1}?`)) {
      advance.mutate(currentRound);
    }
  };

  const exportBracket = () => {
    if (bracketRef.current === null) return;
    toPng(bracketRef.current, { cacheBust: true, backgroundColor: '#ffffff' })
      .then((dataUrl) => {
        const link = document.createElement('a');
        link.download = 'tournament-bracket.png';
        link.href = dataUrl;
        link.click();
      })
      .catch((err) => {
        console.error('Export failed', err);
      });
  };

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-primary">Tournament Bracket</h1>
          <p className="text-muted-foreground">Visualize the road to the championship</p>
        </div>
        <div className="flex gap-3">
          {hasMatchups && (
            <Button variant="outline" onClick={exportBracket}>
              <Download className="mr-2 h-4 w-4" /> Export PNG
            </Button>
          )}
          {!hasMatchups ? (
             <Button onClick={handleGenerate} disabled={generate.isPending} className="bg-primary">
               <Wand2 className="mr-2 h-4 w-4" />
               {generate.isPending ? "Generating..." : "Generate Bracket"}
             </Button>
          ) : (
             <Button onClick={handleAdvance} disabled={advance.isPending} className="bg-accent text-white hover:bg-accent/90">
               <Trophy className="mr-2 h-4 w-4" />
               {advance.isPending ? "Advancing..." : `Advance Round ${currentRound}`}
             </Button>
          )}
          {hasMatchups && (
            <Button variant="outline" size="icon" onClick={() => generate.mutate()} title="Regenerate">
              <RefreshCw className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {!hasMatchups ? (
        <div className="text-center py-20 bg-card rounded-3xl border-2 border-dashed border-border">
          <Trophy className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-bold text-foreground">No Bracket Generated Yet</h3>
          <p className="text-muted-foreground max-w-md mx-auto mt-2 mb-6">
            Ensure you have participants created and seeded before generating the tournament bracket.
          </p>
          <Button onClick={handleGenerate} className="bg-primary">Generate Now</Button>
        </div>
      ) : (
        <div className="overflow-x-auto pb-12">
          <div ref={bracketRef} className="min-w-[1000px] flex justify-between gap-8 relative p-8 bg-white rounded-3xl">
            {matchupsByRound.map((roundMatchups, roundIndex) => (
              <div key={roundIndex} className="flex-1 flex flex-col justify-around relative">
                <div className="text-center mb-6 font-bold text-primary/70 uppercase tracking-widest text-sm">
                  {roundIndex === 3 ? "Championship" : `Round ${roundIndex + 1}`}
                </div>
                
                {roundMatchups.map((match, matchIndex) => (
                  <MatchCard 
                    key={match.id} 
                    match={match} 
                    isFinal={roundIndex === 3}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
}

function MatchCard({ match, isFinal }: { match: any, isFinal?: boolean }) {
  const p1Winner = match.winnerId === match.participant1Id;
  const p2Winner = match.winnerId === match.participant2Id;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "relative bg-card rounded-xl border shadow-sm transition-all duration-300 w-full mb-4",
        isFinal ? "border-accent shadow-lg shadow-accent/10 scale-110 my-10" : "border-border/60"
      )}
    >
      {/* Participant 1 */}
      <div className={cn(
        "flex justify-between items-center p-3 border-b border-border/30 rounded-t-xl transition-colors",
        p1Winner ? "bg-accent/10" : ""
      )}>
        <span className={cn("font-medium text-sm truncate", !match.p1Name && "text-muted-foreground italic")}>
          {match.p1Name || "TBD"}
        </span>
        {p1Winner && <Trophy className="h-3 w-3 text-accent" />}
      </div>

      {/* Participant 2 */}
      <div className={cn(
        "flex justify-between items-center p-3 rounded-b-xl transition-colors",
        p2Winner ? "bg-accent/10" : ""
      )}>
        <span className={cn("font-medium text-sm truncate", !match.p2Name && "text-muted-foreground italic")}>
          {match.p2Name || "TBD"}
        </span>
        {p2Winner && <Trophy className="h-3 w-3 text-accent" />}
      </div>
      
      {/* Connector Line (Right) - unless final */}
      {!isFinal && (
        <div className="absolute top-1/2 -right-4 w-4 h-px bg-border/60" />
      )}
    </motion.div>
  );
}
