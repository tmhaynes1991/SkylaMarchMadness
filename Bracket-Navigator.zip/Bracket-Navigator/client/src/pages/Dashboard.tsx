import { useTournamentState, useStats, useParticipants } from "@/hooks/use-tournament";
import { Layout } from "@/components/Layout";
import { StatsCard } from "@/components/StatsCard";
import { 
  Users, 
  Trophy, 
  Target, 
  Calendar,
  ArrowRight,
  TrendingUp 
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

export default function Dashboard() {
  const { data: state, isLoading: isStateLoading } = useTournamentState();
  const { data: stats, isLoading: isStatsLoading } = useStats();
  const { data: participants, isLoading: isParticipantsLoading } = useParticipants();

  if (isStateLoading || isStatsLoading || isParticipantsLoading) {
    return (
      <Layout>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        </div>
        <Skeleton className="h-96 rounded-2xl mt-8" />
      </Layout>
    );
  }

  const currentRound = state?.currentRound || 1;
  const roundName = state?.rounds.find(r => r.id === currentRound)?.name || `Round ${currentRound}`;
  const totalLoans = stats?.reduce((sum, s) => sum + (s.weeklyLoans || 0), 0) || 0;
  const topPerformer = stats?.sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0))[0];
  const topParticipant = participants?.find(p => p.id === topPerformer?.participantId);

  const highestDP = stats?.sort((a, b) => Number(b.dpPct || 0) - Number(a.dpPct || 0))[0];
  const dpLeader = participants?.find(p => p.id === highestDP?.participantId);

  const highestGAP = stats?.sort((a, b) => Number(b.gapPct || 0) - Number(a.gapPct || 0))[0];
  const gapLeader = participants?.find(p => p.id === highestGAP?.participantId);

  const highestMBP = stats?.sort((a, b) => Number(b.mbpPct || 0) - Number(a.mbpPct || 0))[0];
  const mbpLeader = participants?.find(p => p.id === highestMBP?.participantId);

  const mostProtected = stats?.sort((a, b) => ((b.autoLoansCount || 0) + (b.helocCount || 0)) - ((a.autoLoansCount || 0) + (a.helocCount || 0)))[0];
  const protectedLeader = participants?.find(p => p.id === mostProtected?.participantId);

  // Chart Data Preparation
  const chartData = stats
    ?.filter(s => s.roundNumber === currentRound)
    .sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0))
    .slice(0, 10)
    .map(s => {
      const p = participants?.find(part => part.id === s.participantId);
      return {
        name: p?.name || 'Unknown',
        score: s.totalScore || 0,
      };
    });

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-primary font-display">March Madness</h1>
          <p className="text-muted-foreground mt-1">Lending Tournament 2025</p>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/bracket">
            <Button className="bg-accent hover:bg-accent/90 text-white font-semibold shadow-lg shadow-accent/20">
              View Bracket <Trophy className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          title="Current Stage" 
          value={roundName} 
          subValue="Active Round" 
          icon={Calendar} 
          color="primary"
        />
        <StatsCard 
          title="Top Performer" 
          value={topParticipant?.name?.split(' ')[0] || "None"} 
          subValue={`${topPerformer?.totalScore || 0} Points`} 
          icon={Trophy} 
          color="secondary"
        />
        <StatsCard 
          title="DP Leader" 
          value={dpLeader?.name?.split(' ')[0] || "None"} 
          subValue={`${highestDP?.dpPct || 0}%`} 
          icon={TrendingUp} 
          color="default"
        />
        <StatsCard 
          title="Protected Leader" 
          value={protectedLeader?.name?.split(' ')[0] || "None"} 
          subValue={`${(mostProtected?.autoLoansCount || 0) + (mostProtected?.helocCount || 0)} Loans`} 
          icon={Target} 
          color="default"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
        <StatsCard 
          title="GAP Leader" 
          value={gapLeader?.name?.split(' ')[0] || "None"} 
          subValue={`${highestGAP?.gapPct || 0}%`} 
          icon={TrendingUp} 
          color="default"
        />
        <StatsCard 
          title="MBP Leader" 
          value={mbpLeader?.name?.split(' ')[0] || "None"} 
          subValue={`${highestMBP?.mbpPct || 0}%`} 
          icon={TrendingUp} 
          color="default"
        />
      </div>

      {/* Main Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-border/50 shadow-lg shadow-black/5">
          <CardHeader>
            <CardTitle>Top 10 Performers - {roundName}</CardTitle>
          </CardHeader>
          <CardContent className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748B' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748B' }} />
                <Tooltip 
                  cursor={{ fill: '#F1F5F9' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="score" radius={[8, 8, 0, 0]}>
                  {chartData?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index < 3 ? 'var(--primary)' : '#94A3B8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activity / Next Steps */}
        <div className="space-y-6">
          <Card className="bg-primary text-primary-foreground border-none shadow-xl shadow-primary/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl" />
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-accent/20 rounded-full -ml-12 -mb-12 blur-2xl" />
            
            <CardHeader>
              <CardTitle className="text-white">Next Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 relative z-10">
              <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/10 hover:bg-white/15 transition-colors cursor-pointer group">
                <Link href="/import">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-white">Import Stats</h4>
                      <p className="text-sm text-white/70">Update metrics for {roundName}</p>
                    </div>
                    <UploadIcon className="w-5 h-5 text-accent group-hover:scale-110 transition-transform" />
                  </div>
                </Link>
              </div>
              
              <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/10 hover:bg-white/15 transition-colors cursor-pointer group">
                <Link href="/bracket">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-white">Manage Bracket</h4>
                      <p className="text-sm text-white/70">Advance winners to next round</p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-accent group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

function UploadIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" x2="12" y1="3" y2="15" />
    </svg>
  );
}
