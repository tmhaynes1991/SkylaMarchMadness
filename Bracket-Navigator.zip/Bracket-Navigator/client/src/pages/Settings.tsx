import { Layout } from "@/components/Layout";
import { useTournamentState, useResetTournament, useUpdateSettings, useBulkCreateParticipants, useParticipants, useDeleteParticipant } from "@/hooks/use-tournament";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { AlertTriangle, Save, Upload, Users, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect, useRef } from "react";
import Papa from "papaparse";

export default function Settings() {
  const { data: state, isLoading } = useTournamentState();
  const { data: participants } = useParticipants();
  const reset = useResetTournament();
  const update = useUpdateSettings();
  const bulkCreateParticipants = useBulkCreateParticipants();
  const deleteParticipant = useDeleteParticipant();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [scoring, setScoring] = useState<any>(null);

  useEffect(() => {
    if (state?.scoring) {
      setScoring(state.scoring);
    }
  }, [state]);

  if (isLoading || !scoring) return <Layout>Loading...</Layout>;

  const handleSaveScoring = () => {
    update.mutate({ key: 'scoring', value: scoring }, {
      onSuccess: () => toast({ title: "Settings Saved" })
    });
  };

  const handleReset = () => {
    if (confirm("DANGER: This will wipe all stats and matchups. Are you sure?")) {
      reset.mutate(undefined, {
        onSuccess: () => toast({ title: "Tournament Reset" })
      });
    }
  };

  const handleDeleteParticipant = (id: number, name: string) => {
    if (confirm(`Are you sure you want to delete ${name}? This will remove their stats and may break existing bracket matchups.`)) {
      deleteParticipant.mutate(id, {
        onSuccess: () => toast({ title: "Participant Deleted", description: `${name} has been removed.` }),
        onError: (err: any) => toast({ title: "Delete Failed", description: err.message, variant: "destructive" })
      });
    }
  };

  const handleParticipantUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      Papa.parse(e.target.files[0], {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          const newParticipants = results.data.map((row: any) => ({
            name: row.Name || row.name,
            lenderId: row.LenderID || row.lenderId || row.ID || row.id,
            seed: Number(row.Seed || row.seed || 0),
            isActive: true
          })).filter(p => p.name && p.lenderId);

          if (newParticipants.length === 0) {
            toast({
              title: "Import Failed",
              description: "No valid participants found. Check CSV headers (Name, LenderID).",
              variant: "destructive"
            });
            return;
          }

          bulkCreateParticipants.mutate(newParticipants, {
            onSuccess: () => {
              toast({ title: "Import Successful", description: `Added ${newParticipants.length} participants.` });
              if (fileInputRef.current) fileInputRef.current.value = "";
            },
            onError: (err: any) => {
              toast({ title: "Import Failed", description: err.message, variant: "destructive" });
            }
          });
        }
      });
    }
  };

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display text-primary">Settings</h1>
        <p className="text-muted-foreground">Configure tournament rules and manage participants</p>
      </div>

      <Tabs defaultValue="scoring" className="space-y-6">
        <TabsList className="bg-white p-1 rounded-xl border border-border/50">
          <TabsTrigger value="scoring" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">Scoring Rules</TabsTrigger>
          <TabsTrigger value="participants" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">Participants</TabsTrigger>
          <TabsTrigger value="rounds" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">Rounds & Dates</TabsTrigger>
          <TabsTrigger value="danger" className="rounded-lg data-[state=active]:bg-destructive data-[state=active]:text-white">Danger Zone</TabsTrigger>
        </TabsList>

        <TabsContent value="scoring">
          <Card>
            <CardHeader>
              <CardTitle>Scoring Configuration</CardTitle>
              <CardDescription>Adjust points for different metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                   <Label>Auto Loan Bonus (Points)</Label>
                   <Input 
                     type="number" 
                     value={scoring.bonuses?.autoLoan} 
                     onChange={(e) => setScoring({...scoring, bonuses: {...scoring.bonuses, autoLoan: Number(e.target.value)}})}
                   />
                </div>
                <div className="space-y-2">
                   <Label>HELOC Bonus (Points)</Label>
                   <Input 
                     type="number" 
                     value={scoring.bonuses?.heloc} 
                     onChange={(e) => setScoring({...scoring, bonuses: {...scoring.bonuses, heloc: Number(e.target.value)}})}
                   />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Minimum Weekly Loans (Eligibility)</Label>
                <Input 
                  type="number" 
                  value={scoring.minWeeklyLoans} 
                  onChange={(e) => setScoring({...scoring, minWeeklyLoans: Number(e.target.value)})}
                />
              </div>

              <Button onClick={handleSaveScoring} disabled={update.isPending} className="bg-primary">
                <Save className="mr-2 h-4 w-4" /> Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="participants">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Bulk Import</CardTitle>
                <CardDescription>Upload participants via CSV</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted rounded-lg text-xs font-mono mb-4">
                  Name,LenderID,Seed
                </div>
                <div className="flex flex-col gap-2">
                  <input 
                    type="file" 
                    accept=".csv" 
                    className="hidden" 
                    ref={fileInputRef}
                    onChange={handleParticipantUpload}
                  />
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={bulkCreateParticipants.isPending}
                  >
                    <Upload className="mr-2 h-4 w-4" /> 
                    {bulkCreateParticipants.isPending ? "Importing..." : "Upload CSV"}
                  </Button>
                  <Button
                    className="w-full"
                    variant="secondary"
                    onClick={() => {
                      const csvContent = "data:text/csv;charset=utf-8,Name,LenderID,Seed\nJohn Doe,1234,1\nJane Doe,5678,2";
                      const encodedUri = encodeURI(csvContent);
                      const link = document.createElement("a");
                      link.setAttribute("href", encodedUri);
                      link.setAttribute("download", "participants_template.csv");
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                  >
                    Download Template
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Current Participants</CardTitle>
                  <span className="text-xs font-medium px-2 py-1 bg-primary/10 text-primary rounded-full">
                    {participants?.length || 0} Total
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="max-h-[400px] overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-background border-b">
                      <tr>
                        <th className="text-left py-2">Name</th>
                        <th className="text-left py-2">Lender ID</th>
                        <th className="text-right py-2">Seed</th>
                        <th className="w-10"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {participants?.map((p) => (
                        <tr key={p.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors group">
                          <td className="py-2 font-medium">{p.name}</td>
                          <td className="py-2 text-muted-foreground">{p.lenderId}</td>
                          <td className="py-2 text-right">{p.seed || '-'}</td>
                          <td className="py-2 text-right">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => handleDeleteParticipant(p.id, p.name)}
                              disabled={deleteParticipant.isPending}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                      {(!participants || participants.length === 0) && (
                        <tr>
                          <td colSpan={3} className="py-8 text-center text-muted-foreground italic">
                            No participants yet. Import them to get started!
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="rounds">
           <Card>
             <CardHeader>
               <CardTitle>Round Schedule</CardTitle>
               <CardDescription>Configure the start and end dates for each round.</CardDescription>
             </CardHeader>
             <CardContent>
                <p className="text-sm text-muted-foreground italic">Currently using default schedule from prompt. Round dates update coming in next version.</p>
             </CardContent>
           </Card>
        </TabsContent>

        <TabsContent value="danger">
          <Card className="border-destructive/20 bg-destructive/5">
            <CardHeader>
              <CardTitle className="text-destructive flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" /> Danger Zone
              </CardTitle>
              <CardDescription>Irreversible actions</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="destructive" onClick={handleReset} disabled={reset.isPending}>
                Reset Tournament Data
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </Layout>
  );
}
