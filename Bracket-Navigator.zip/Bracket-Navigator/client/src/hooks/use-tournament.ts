import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { 
  type Participant, 
  type InsertParticipant, 
  type RoundStats, 
  type InsertRoundStats,
  type Matchup,
  type Settings,
  type TournamentState
} from "@shared/schema";

// === SETTINGS & STATE ===

export function useTournamentState() {
  return useQuery<TournamentState>({
    queryKey: [api.settings.get.path],
    queryFn: async () => {
      const res = await fetch(api.settings.get.path);
      if (!res.ok) throw new Error("Failed to fetch tournament state");
      return await res.json();
    }
  });
}

export function useUpdateSettings() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ key, value }: { key: string; value: any }) => {
      const res = await fetch(api.settings.update.path, {
        method: api.settings.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (!res.ok) throw new Error("Failed to update settings");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.settings.get.path] }),
  });
}

export function useResetTournament() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.settings.reset.path, { method: api.settings.reset.method });
      if (!res.ok) throw new Error("Failed to reset tournament");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries(), // Invalidate everything
  });
}

// === PARTICIPANTS ===

export function useParticipants() {
  return useQuery<Participant[]>({
    queryKey: [api.participants.list.path],
    queryFn: async () => {
      const res = await fetch(api.participants.list.path);
      if (!res.ok) throw new Error("Failed to fetch participants");
      return api.participants.list.responses[200].parse(await res.json());
    }
  });
}

export function useCreateParticipant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertParticipant) => {
      const validated = api.participants.create.input.parse(data);
      const res = await fetch(api.participants.create.path, {
        method: api.participants.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to create participant");
      return api.participants.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.participants.list.path] }),
  });
}

export function useBulkCreateParticipants() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertParticipant[]) => {
      const validated = api.participants.bulkCreate.input.parse(data);
      const res = await fetch(api.participants.bulkCreate.path, {
        method: api.participants.bulkCreate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to bulk create participants");
      return api.participants.bulkCreate.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.participants.list.path] }),
  });
}

export function useUpdateParticipant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertParticipant>) => {
      const validated = api.participants.update.input.parse(updates);
      const url = buildUrl(api.participants.update.path, { id });
      const res = await fetch(url, {
        method: api.participants.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to update participant");
      return api.participants.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.participants.list.path] }),
  });
}

export function useDeleteParticipant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.participants.delete.path, { id });
      const res = await fetch(url, { method: api.participants.delete.method });
      if (!res.ok) throw new Error("Failed to delete participant");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.participants.list.path] }),
  });
}

// === STATS ===

export function useStats(filters?: { round?: number; participantId?: number }) {
  return useQuery<RoundStats[]>({
    queryKey: [api.stats.list.path, filters],
    queryFn: async () => {
      let url = api.stats.list.path;
      if (filters) {
        const params = new URLSearchParams();
        if (filters.round) params.append("round", filters.round.toString());
        if (filters.participantId) params.append("participantId", filters.participantId.toString());
        url += `?${params.toString()}`;
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch stats");
      return api.stats.list.responses[200].parse(await res.json());
    }
  });
}

export function useUpdateStats() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertRoundStats) => {
      const validated = api.stats.update.input.parse(data);
      const res = await fetch(api.stats.update.path, {
        method: api.stats.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to update stats");
      return api.stats.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.stats.list.path] }),
  });
}

export function useBulkUpdateStats() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertRoundStats[]) => {
      const validated = api.stats.bulkUpdate.input.parse(data);
      const res = await fetch(api.stats.bulkUpdate.path, {
        method: api.stats.bulkUpdate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to bulk update stats");
      return api.stats.bulkUpdate.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.stats.list.path] }),
  });
}

// === MATCHUPS ===

export function useMatchups() {
  return useQuery<(Matchup & { p1Name?: string; p2Name?: string })[]>({
    queryKey: [api.matchups.list.path],
    queryFn: async () => {
      const res = await fetch(api.matchups.list.path);
      if (!res.ok) throw new Error("Failed to fetch matchups");
      return api.matchups.list.responses[200].parse(await res.json());
    }
  });
}

export function useGenerateMatchups() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.matchups.generate.path, { method: api.matchups.generate.method });
      if (!res.ok) throw new Error("Failed to generate matchups");
      return api.matchups.generate.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.matchups.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.settings.get.path] });
    },
  });
}

export function useAdvanceRound() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (round: number) => {
      const res = await fetch(api.matchups.advance.path, {
        method: api.matchups.advance.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ round }),
      });
      if (!res.ok) throw new Error("Failed to advance round");
      return api.matchups.advance.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.matchups.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.settings.get.path] });
    },
  });
}

export function useOverrideMatchupWinner() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, winnerId }: { id: number; winnerId: number | null }) => {
      const url = buildUrl(api.matchups.override.path, { id });
      const res = await fetch(url, {
        method: api.matchups.override.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ winnerId }),
      });
      if (!res.ok) throw new Error("Failed to override winner");
      return api.matchups.override.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.matchups.list.path] }),
  });
}
