## Packages
papaparse | For parsing CSV files for data import
recharts | For visualizing tournament statistics and score distributions
framer-motion | For smooth animations in the bracket and page transitions
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
