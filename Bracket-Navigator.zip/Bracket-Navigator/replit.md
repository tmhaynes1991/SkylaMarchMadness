# Lending Tournament Tracker

## Overview

A March Madness-style lending tournament tracker for Credit Unions that manages participant scoring, single-elimination brackets, and performance metrics. The application tracks lender performance across multiple rounds with configurable scoring rules based on GAP penetration, MBP penetration, Debt Protection metrics, and bonus points for fully protected loans.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Animations**: Framer Motion for bracket and page transitions
- **Charts**: Recharts for data visualization
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: REST endpoints defined in `shared/routes.ts` with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: Express sessions with connect-pg-simple for PostgreSQL session storage

### Data Storage
- **Database**: PostgreSQL (configured via DATABASE_URL environment variable)
- **Schema Location**: `shared/schema.ts` using Drizzle table definitions
- **Migrations**: Drizzle Kit with output to `./migrations` directory

### Key Data Models
- **Settings**: JSON storage for tournament configuration (scoring rules, round dates)
- **Participants**: Lender profiles with unique IDs and seeding
- **Round Stats**: Per-participant, per-round metrics including penetration percentages and loan counts
- **Matchups**: Bracket structure with head-to-head pairings and winner tracking

### Scoring System
The tournament implements a tiered scoring system:
- GAP Penetration: 45-49.99% = 1pt, 50-59.99% = 3pts, 60%+ = 4pts
- MBP Penetration: 15-17.99% = 1pt, 18-21.99% = 3pts, 22%+ = 4pts
- Debt Protection: 30-34.99% = 1pt, 35-39.99% = 3pts, 40%+ = 4pts
- Bonus points for fully protected auto loans and HELOCs (+3 each)
- Minimum 3 loans/week required for eligibility

### Project Structure
```
├── client/           # React frontend
│   └── src/
│       ├── components/   # UI components including shadcn/ui
│       ├── pages/        # Route pages (Dashboard, Bracket, Leaderboard, etc.)
│       ├── hooks/        # Custom hooks including tournament data hooks
│       └── lib/          # Utilities and query client
├── server/           # Express backend
│   ├── routes.ts     # API route handlers
│   ├── storage.ts    # Database operations interface
│   └── db.ts         # Drizzle database connection
├── shared/           # Shared code between client/server
│   ├── schema.ts     # Drizzle schema definitions
│   └── routes.ts     # API route type definitions
└── migrations/       # Database migrations
```

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### UI Component Libraries
- **shadcn/ui**: Pre-built accessible components using Radix UI primitives
- **Radix UI**: Headless UI primitives for dialogs, menus, tooltips, etc.

### Data Processing
- **PapaParse**: CSV parsing for participant and stats data import
- **Zod**: Schema validation for API requests and form data

### Build & Development
- **Vite**: Frontend build tool with HMR support
- **esbuild**: Server-side bundling for production
- **TypeScript**: Full type safety across the stack