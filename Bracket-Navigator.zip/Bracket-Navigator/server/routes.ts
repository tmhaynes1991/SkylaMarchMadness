
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { type ScoringConfig } from "@shared/schema";

const DEFAULT_SCORING: ScoringConfig = {
  minWeeklyLoans: 3,
  gap: { tiers: [{ min: 60, points: 4 }, { min: 50, points: 3 }, { min: 45, points: 1 }] },
  mbp: { tiers: [{ min: 22, points: 4 }, { min: 18, points: 3 }, { min: 15, points: 1 }] },
  dp: { tiers: [{ min: 40, points: 4 }, { min: 35, points: 3 }, { min: 30, points: 1 }] },
  bonuses: { autoLoan: 3, heloc: 3 }
};

const DEFAULT_ROUNDS = [
  { id: 1, name: "Round 1", startDate: "2026-03-16", endDate: "2026-03-20" },
  { id: 2, name: "Round 2", startDate: "2026-03-23", endDate: "2026-03-27" },
  { id: 3, name: "Round 3", startDate: "2026-03-30", endDate: "2026-04-03" }, // Adjusted based on prompt ambiguity (R3 same as R1?), assuming linear
  { id: 4, name: "Championship", startDate: "2026-04-06", endDate: "2026-04-10" }
];

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === Settings ===
  app.get(api.settings.get.path, async (_req, res) => {
    const scoring = await storage.getSettings('scoring') || { key: 'scoring', value: DEFAULT_SCORING };
    const rounds = await storage.getSettings('rounds') || { key: 'rounds', value: DEFAULT_ROUNDS };
    const currentRound = await storage.getSettings('current_round') || { key: 'current_round', value: 1 };
    
    res.json({
      scoring: scoring.value,
      rounds: rounds.value,
      currentRound: currentRound.value
    });
  });

  app.post(api.settings.update.path, async (req, res) => {
    const { key, value } = req.body;
    const updated = await storage.updateSettings(key, value);
    res.json(updated);
  });
  
  app.post(api.settings.reset.path, async (_req, res) => {
    await storage.updateSettings('scoring', DEFAULT_SCORING);
    await storage.updateSettings('rounds', DEFAULT_ROUNDS);
    await storage.updateSettings('current_round', 1);
    await storage.resetAllData();
    res.json({ message: "Tournament data and settings reset to defaults" });
  });

  // === Participants ===
  app.get(api.participants.list.path, async (_req, res) => {
    const participants = await storage.getParticipants();
    res.json(participants);
  });

  app.post(api.participants.create.path, async (req, res) => {
    try {
      const input = api.participants.create.input.parse(req.body);
      const created = await storage.createParticipant(input);
      res.status(201).json(created);
    } catch (e) {
      if (e instanceof z.ZodError) {
        res.status(400).json(e.errors);
      } else {
        res.status(500).json({ message: "Failed to create participant" });
      }
    }
  });

  app.post(api.participants.bulkCreate.path, async (req, res) => {
    try {
      const input = api.participants.bulkCreate.input.parse(req.body);
      // Simple loop for now, could optimize
      // Check for existing lenderIds to avoid duplicates error
      // Ideally should be an upsert or check first.
      // For this MVP, let's assume clean imports or catch errors
      const created = await storage.bulkCreateParticipants(input);
      res.status(201).json(created);
    } catch (e) {
      res.status(500).json({ message: "Bulk create failed", details: String(e) });
    }
  });

  app.put(api.participants.update.path, async (req, res) => {
    const id = parseInt(String(req.params.id));
    const updated = await storage.updateParticipant(id, req.body);
    res.json(updated);
  });

  app.delete(api.participants.delete.path, async (req, res) => {
    const id = parseInt(String(req.params.id));
    await storage.deleteParticipant(id);
    res.status(204).end();
  });

  // === Stats & Scoring Logic ===
  function calculateScore(stats: any, config: ScoringConfig) {
    let score = 0;
    
    // Check eligibility
    const isEligible = stats.weeklyLoans >= config.minWeeklyLoans;
    
    if (!isEligible) return { score: 0, isEligible: false };

    // Tiers
    const getPoints = (val: number, tiers: {min: number, points: number}[]) => {
      // Sort tiers desc
      const sorted = [...tiers].sort((a, b) => b.min - a.min);
      for (const t of sorted) {
        if (Number(val) >= t.min) return t.points;
      }
      return 0;
    };

    score += getPoints(Number(stats.gapPct), config.gap.tiers);
    score += getPoints(Number(stats.mbpPct), config.mbp.tiers);
    score += getPoints(Number(stats.dpPct), config.dp.tiers);

    // Bonuses
    score += (stats.autoLoansCount || 0) * config.bonuses.autoLoan;
    score += (stats.helocCount || 0) * config.bonuses.heloc;

    return { score, isEligible: true };
  }

  app.get(api.stats.list.path, async (req, res) => {
    const round = req.query.round ? Number(req.query.round) : undefined;
    const pid = req.query.participantId ? Number(req.query.participantId) : undefined;
    const stats = await storage.getRoundStats(round, pid);
    res.json(stats);
  });

  app.post(api.stats.update.path, async (req, res) => {
    try {
      const input = api.stats.update.input.parse(req.body);
      
      // Calculate score before saving
      const scoringSetting = await storage.getSettings('scoring');
      const config = (scoringSetting?.value as ScoringConfig) || DEFAULT_SCORING;
      
      const { score, isEligible } = calculateScore(input, config);
      
      const saved = await storage.updateRoundStats({
        ...input,
        totalScore: score,
        isEligible
      } as any);
      res.json(saved);
    } catch (e) {
      console.error(e);
      res.status(500).json({ message: "Failed to update stats" });
    }
  });
  
  app.post(api.stats.bulkUpdate.path, async (req, res) => {
     try {
      const inputs = api.stats.bulkUpdate.input.parse(req.body);
      const scoringSetting = await storage.getSettings('scoring');
      const config = (scoringSetting?.value as ScoringConfig) || DEFAULT_SCORING;
      
      const processed = inputs.map(input => {
         const { score, isEligible } = calculateScore(input, config);
         return {
            ...input,
            totalScore: score,
            isEligible
         };
      });

      const saved = await storage.bulkUpdateRoundStats(processed as any);
      res.json(saved);
     } catch (e) {
      console.error(e);
      res.status(500).json({ message: "Failed bulk update" });
     }
  });


  // === Matchups ===
  app.get(api.matchups.list.path, async (_req, res) => {
    const matchups = await storage.getMatchups();
    const participants = await storage.getParticipants();
    const pMap = new Map(participants.map(p => [p.id, p]));
    
    const enriched = matchups.map(m => ({
      ...m,
      p1Name: m.participant1Id ? pMap.get(m.participant1Id)?.name : 'Bye',
      p2Name: m.participant2Id ? pMap.get(m.participant2Id)?.name : 'Bye'
    }));
    
    res.json(enriched);
  });

  app.post(api.matchups.generate.path, async (_req, res) => {
    // Basic seeding logic for Round 1
    const participants = await storage.getParticipants();
    // Shuffle or use seed
    const active = participants.filter(p => p.isActive);
    
    // Clear existing? Maybe not if we want to be safe. 
    // For now assume "Start Tournament" button clears and generates.
    await storage.clearMatchups();
    
    const count = active.length;
    // Power of 2 logic simplified: just pair them up
    // If odd, one gets a bye (null p2)
    
    const matches = [];
    for (let i = 0; i < count; i += 2) {
      matches.push({
        roundNumber: 1,
        matchId: (i / 2) + 1,
        participant1Id: active[i].id,
        participant2Id: active[i + 1] ? active[i + 1].id : null, 
        winnerId: active[i + 1] ? null : active[i].id, 
        manualWinnerId: null
      });
    }
    
    const created = [];
    for (const m of matches) {
      created.push(await storage.createMatchup(m));
    }
    
    // Create placeholders for future rounds? 
    // Or generate them as we advance. Advancing is better for dynamic.
    
    res.json(created);
  });

  app.post(api.matchups.advance.path, async (req, res) => {
    // Logic to determine winners of current round and create next round matches
    const { round } = req.body;
    const currentMatches = await storage.getMatchups(round);
    
    let advancedCount = 0;
    const winners = [];

    for (const match of currentMatches) {
      // Determine winner if not already set
      let winnerId = match.winnerId || match.manualWinnerId;
      
      if (!winnerId && match.participant1Id && match.participant2Id) {
        // Compare scores
        const stats1List = await storage.getRoundStats(round, match.participant1Id);
        const stats2List = await storage.getRoundStats(round, match.participant2Id);
        
        const s1 = stats1List[0];
        const s2 = stats2List[0];
        
        const score1 = s1?.isEligible ? (s1?.totalScore || 0) : -1; // Ineligible = -1
        const score2 = s2?.isEligible ? (s2?.totalScore || 0) : -1;
        
        if (score1 > score2) winnerId = match.participant1Id;
        else if (score2 > score1) winnerId = match.participant2Id;
        else {
           // Tie breaker logic: 
           // 1. Most fully protected auto loans (autoLoansCount)
           // 2. Higher Debt Protection % (dpPct)
           // 3. Higher GAP % (gapPct)
           // If still tied, random or P1?
           const auto1 = s1?.autoLoansCount || 0;
           const auto2 = s2?.autoLoansCount || 0;
           
           if (auto1 > auto2) winnerId = match.participant1Id;
           else if (auto2 > auto1) winnerId = match.participant2Id;
           else {
             const dp1 = Number(s1?.dpPct || 0);
             const dp2 = Number(s2?.dpPct || 0);
             if (dp1 > dp2) winnerId = match.participant1Id;
             else if (dp2 > dp1) winnerId = match.participant2Id;
             else {
                const gap1 = Number(s1?.gapPct || 0);
                const gap2 = Number(s2?.gapPct || 0);
                if (gap1 >= gap2) winnerId = match.participant1Id; // Fallback to P1
                else winnerId = match.participant2Id;
             }
           }
        }
        
        // Update match with determined winner
        await storage.updateMatchup(match.id, { winnerId });
      } else if (!winnerId && match.participant1Id && !match.participant2Id) {
         // Bye
         winnerId = match.participant1Id;
         await storage.updateMatchup(match.id, { winnerId });
      }

      if (winnerId) winners.push(winnerId);
    }

    // Generate next round matches
    if (winners.length > 0) {
      const nextRound = round + 1;
      // Check if next round already exists
      const existingNext = await storage.getMatchups(nextRound);
      if (existingNext.length === 0) {
        for (let i = 0; i < winners.length; i += 2) {
          await storage.createMatchup({
            roundNumber: nextRound,
            matchId: (i / 2) + 1,
            participant1Id: winners[i],
            participant2Id: winners[i+1] || null,
            winnerId: winners[i+1] ? null : winners[i], 
            manualWinnerId: null
          });
          advancedCount++;
        }
        // Update current round
        await storage.updateSettings('current_round', nextRound);
      }
    }

    res.json({ message: "Round processed", advancedCount });
  });
  
  app.post(api.matchups.override.path, async (req, res) => {
    const id = parseInt(String(req.params.id));
    const { winnerId } = req.body;
    const updated = await storage.updateMatchup(id, { manualWinnerId: winnerId });
    res.json(updated);
  });

  // Seed data if empty
  /* 
  const participants = await storage.getParticipants();
  if (participants.length === 0) {
    ... 
  }
  */

  return httpServer;
}
