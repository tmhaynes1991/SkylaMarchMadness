
import { db } from "./db";
import {
  participants, roundStats, matchups, settings,
  type Participant, type InsertParticipant,
  type RoundStats, type InsertRoundStats,
  type Matchup, type Settings, type TournamentState,
  type ScoringConfig
} from "@shared/schema";
import { eq, and, asc, desc } from "drizzle-orm";

export interface IStorage {
  // Settings
  getSettings(key: string): Promise<Settings | undefined>;
  updateSettings(key: string, value: any): Promise<Settings>;
  getAllSettings(): Promise<Map<string, any>>;

  // Participants
  getParticipants(): Promise<Participant[]>;
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  updateParticipant(id: number, participant: Partial<InsertParticipant>): Promise<Participant>;
  bulkCreateParticipants(participantsData: InsertParticipant[]): Promise<Participant[]>;
  
  // Stats
  getRoundStats(roundNumber?: number, participantId?: number): Promise<RoundStats[]>;
  updateRoundStats(stats: InsertRoundStats): Promise<RoundStats>;
  bulkUpdateRoundStats(stats: InsertRoundStats[]): Promise<RoundStats[]>;
  
  // Matchups
  getMatchups(roundNumber?: number): Promise<Matchup[]>;
  createMatchup(matchup: Omit<Matchup, "id">): Promise<Matchup>;
  updateMatchup(id: number, updates: Partial<Matchup>): Promise<Matchup>;
  deleteParticipant(id: number): Promise<void>;
  clearMatchups(): Promise<void>;
  resetAllData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Settings
  async getSettings(key: string): Promise<Settings | undefined> {
    const [result] = await db.select().from(settings).where(eq(settings.key, key));
    return result;
  }

  async updateSettings(key: string, value: any): Promise<Settings> {
    const [existing] = await db.select().from(settings).where(eq(settings.key, key));
    if (existing) {
      const [updated] = await db.update(settings)
        .set({ value })
        .where(eq(settings.key, key))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(settings)
        .values({ key, value })
        .returning();
      return created;
    }
  }

  async getAllSettings(): Promise<Map<string, any>> {
    const all = await db.select().from(settings);
    const map = new Map();
    all.forEach(s => map.set(s.key, s.value));
    return map;
  }

  // Participants
  async getParticipants(): Promise<Participant[]> {
    return await db.select().from(participants).orderBy(participants.name);
  }

  async createParticipant(participant: InsertParticipant): Promise<Participant> {
    const [created] = await db.insert(participants).values(participant).returning();
    return created;
  }
  
  async updateParticipant(id: number, updates: Partial<InsertParticipant>): Promise<Participant> {
    const [updated] = await db.update(participants).set(updates).where(eq(participants.id, id)).returning();
    return updated;
  }

  async bulkCreateParticipants(data: InsertParticipant[]): Promise<Participant[]> {
    if (data.length === 0) return [];
    return await db.insert(participants).values(data).returning();
  }

  async deleteParticipant(id: number): Promise<void> {
    // Delete associated stats first
    await db.delete(roundStats).where(eq(roundStats.participantId, id));
    // Nullify in matchups
    await db.update(matchups).set({ participant1Id: null }).where(eq(matchups.participant1Id, id));
    await db.update(matchups).set({ participant2Id: null }).where(eq(matchups.participant2Id, id));
    await db.update(matchups).set({ winnerId: null }).where(eq(matchups.winnerId, id));
    await db.update(matchups).set({ manualWinnerId: null }).where(eq(matchups.manualWinnerId, id));
    // Delete participant
    await db.delete(participants).where(eq(participants.id, id));
  }

  // Stats
  async getRoundStats(roundNumber?: number, participantId?: number): Promise<RoundStats[]> {
    let query = db.select().from(roundStats);
    if (roundNumber) query.where(eq(roundStats.roundNumber, roundNumber));
    // Note: Drizzle query builder chaining for multiple conditionals needs care, simpler to use direct where if both present
    if (roundNumber && participantId) {
       return await db.select().from(roundStats).where(and(eq(roundStats.roundNumber, roundNumber), eq(roundStats.participantId, participantId)));
    } else if (roundNumber) {
       return await db.select().from(roundStats).where(eq(roundStats.roundNumber, roundNumber));
    } else if (participantId) {
       return await db.select().from(roundStats).where(eq(roundStats.participantId, participantId));
    }
    return await db.select().from(roundStats);
  }

  async updateRoundStats(stats: InsertRoundStats): Promise<RoundStats> {
    // Check if exists
    const existing = await db.select().from(roundStats).where(
      and(eq(roundStats.participantId, stats.participantId), eq(roundStats.roundNumber, stats.roundNumber))
    );

    if (existing.length > 0) {
      const [updated] = await db.update(roundStats)
        .set(stats)
        .where(eq(roundStats.id, existing[0].id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(roundStats).values(stats).returning();
      return created;
    }
  }

  async bulkUpdateRoundStats(statsList: InsertRoundStats[]): Promise<RoundStats[]> {
    const results = [];
    for (const stats of statsList) {
      results.push(await this.updateRoundStats(stats));
    }
    return results;
  }

  // Matchups
  async getMatchups(roundNumber?: number): Promise<Matchup[]> {
    if (roundNumber) {
      return await db.select().from(matchups).where(eq(matchups.roundNumber, roundNumber)).orderBy(matchups.matchId);
    }
    return await db.select().from(matchups).orderBy(matchups.roundNumber, matchups.matchId);
  }

  async createMatchup(matchup: Omit<Matchup, "id">): Promise<Matchup> {
    const [created] = await db.insert(matchups).values(matchup).returning();
    return created;
  }

  async updateMatchup(id: number, updates: Partial<Matchup>): Promise<Matchup> {
    const [updated] = await db.update(matchups).set(updates).where(eq(matchups.id, id)).returning();
    return updated;
  }

  async clearMatchups(): Promise<void> {
    await db.delete(matchups);
  }

  async resetAllData(): Promise<void> {
    await db.delete(matchups);
    await db.delete(roundStats);
    await db.delete(participants);
  }
}

export const storage = new DatabaseStorage();
