
import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Settings for the tournament (Scoring rules, dates, etc.)
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g., 'round_dates', 'scoring_rules'
  value: jsonb("value").notNull(),     // JSON storage for flexibility
});

// Participants
export const participants = pgTable("participants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  lenderId: text("lender_id").notNull().unique(),
  isActive: boolean("is_active").default(true),
  seed: integer("seed"), // Initial ranking for bracket generation
});

// Stats per participant per round
export const roundStats = pgTable("round_stats", {
  id: serial("id").primaryKey(),
  participantId: integer("participant_id").references(() => participants.id).notNull(),
  roundNumber: integer("round_number").notNull(), // 1, 2, 3, 4
  
  // Metrics
  weeklyLoans: integer("weekly_loans").default(0),
  gapPct: decimal("gap_pct", { precision: 5, scale: 2 }).default("0"),
  mbpPct: decimal("mbp_pct", { precision: 5, scale: 2 }).default("0"),
  dpPct: decimal("dp_pct", { precision: 5, scale: 2 }).default("0"),
  autoLoansCount: integer("auto_loans_count").default(0),
  helocCount: integer("heloc_count").default(0),
  
  // Computed (can be cached here or calculated on fly, caching is safer for history)
  totalScore: integer("total_score").default(0),
  isEligible: boolean("is_eligible").default(true), // Based on min weekly loans
});

// Matchups for the bracket
export const matchups = pgTable("matchups", {
  id: serial("id").primaryKey(),
  roundNumber: integer("round_number").notNull(), // 1, 2, 3, 4
  matchId: integer("match_id").notNull(), // 1-8 for round 1, etc.
  
  participant1Id: integer("participant1_id").references(() => participants.id),
  participant2Id: integer("participant2_id").references(() => participants.id),
  
  winnerId: integer("winner_id").references(() => participants.id),
  manualWinnerId: integer("manual_winner_id").references(() => participants.id), // Override
});

// === SCHEMAS ===

export const insertParticipantSchema = createInsertSchema(participants).omit({ id: true });
export const insertRoundStatsSchema = createInsertSchema(roundStats).omit({ id: true, totalScore: true, isEligible: true });
export const insertMatchupSchema = createInsertSchema(matchups).omit({ id: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });

// === TYPES ===

export type Participant = typeof participants.$inferSelect;
export type InsertParticipant = z.infer<typeof insertParticipantSchema>;

export type RoundStats = typeof roundStats.$inferSelect;
export type InsertRoundStats = z.infer<typeof insertRoundStatsSchema>;

export type Matchup = typeof matchups.$inferSelect;
export type Settings = typeof settings.$inferSelect;

// App specific types
export interface ScoringConfig {
  minWeeklyLoans: number;
  gap: { tiers: { min: number; points: number }[] };
  mbp: { tiers: { min: number; points: number }[] };
  dp: { tiers: { min: number; points: number }[] };
  bonuses: { autoLoan: number; heloc: number };
}

export interface RoundConfig {
  id: number;
  name: string;
  startDate: string;
  endDate: string;
}

export interface TournamentState {
  currentRound: number;
  rounds: RoundConfig[];
  scoring: ScoringConfig;
}
