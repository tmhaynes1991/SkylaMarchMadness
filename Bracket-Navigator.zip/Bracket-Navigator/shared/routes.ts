
import { z } from 'zod';
import { insertParticipantSchema, insertRoundStatsSchema, insertSettingsSchema, participants, roundStats, matchups, settings } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  settings: {
    get: {
      method: 'GET' as const,
      path: '/api/settings',
      responses: {
        200: z.any(), // Returns TournamentState structure
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/settings',
      input: z.object({
        key: z.string(),
        value: z.any(),
      }),
      responses: {
        200: z.custom<typeof settings.$inferSelect>(),
      },
    },
    reset: {
      method: 'POST' as const,
      path: '/api/settings/reset',
      responses: {
        200: z.object({ message: z.string() }),
      },
    }
  },
  participants: {
    list: {
      method: 'GET' as const,
      path: '/api/participants',
      responses: {
        200: z.array(z.custom<typeof participants.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/participants',
      input: insertParticipantSchema,
      responses: {
        201: z.custom<typeof participants.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    bulkCreate: {
      method: 'POST' as const,
      path: '/api/participants/bulk',
      input: z.array(insertParticipantSchema),
      responses: {
        201: z.array(z.custom<typeof participants.$inferSelect>()),
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/participants/:id',
      input: insertParticipantSchema.partial(),
      responses: {
        200: z.custom<typeof participants.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/participants/:id',
      responses: {
        204: z.void(),
      },
    }
  },
  stats: {
    list: {
      method: 'GET' as const,
      path: '/api/stats',
      input: z.object({ round: z.coerce.number().optional(), participantId: z.coerce.number().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof roundStats.$inferSelect>()),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/stats',
      input: insertRoundStatsSchema,
      responses: {
        200: z.custom<typeof roundStats.$inferSelect>(),
      },
    },
    bulkUpdate: {
      method: 'POST' as const,
      path: '/api/stats/bulk',
      input: z.array(insertRoundStatsSchema),
      responses: {
        200: z.array(z.custom<typeof roundStats.$inferSelect>()),
      },
    }
  },
  matchups: {
    list: {
      method: 'GET' as const,
      path: '/api/matchups',
      responses: {
        200: z.array(z.custom<typeof matchups.$inferSelect & { p1Name?: string, p2Name?: string }>()),
      },
    },
    generate: {
      method: 'POST' as const,
      path: '/api/matchups/generate',
      responses: {
        200: z.array(z.custom<typeof matchups.$inferSelect>()),
      },
    },
    advance: {
      method: 'POST' as const,
      path: '/api/matchups/advance',
      input: z.object({ round: z.number() }),
      responses: {
        200: z.object({ message: z.string(), advancedCount: z.number() }),
      },
    },
    override: {
      method: 'POST' as const,
      path: '/api/matchups/:id/override',
      input: z.object({ winnerId: z.number().nullable() }),
      responses: {
        200: z.custom<typeof matchups.$inferSelect>(),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
